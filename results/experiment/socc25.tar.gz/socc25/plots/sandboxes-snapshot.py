#!/usr/bin/env python

import matplotlib.pyplot as plt
import numpy as np

benchmark_labels = [
    "js/hw",
    "js/html",
    "js/upload",
    "py/hw",
    "py/html",
    "py/upload",
    "py/thumbnail",
    "py/compress",
    "py/mst",
    "py/bfs",
    "py/pr",
    "py/dna"
]

cold_lat = {}
cold_mem = {}
cold_lat["py/hw"] = [228494, 183492, 182895, 233339, 226167, 188139, 244642, 241000, 168917, 175153]
cold_mem["py/hw"] = [215056, 215000, 214972, 57004, 215052, 215048, 215056, 215048, 215056, 215052]
cold_lat["py/mst"] = [216625, 168925, 178788, 168471, 191558, 227945, 229150, 188198, 170331, 239024]
cold_mem["py/mst"] = [215776, 215432, 215544, 215484, 215548, 215552, 215832, 215488, 215432, 215548]
cold_lat["py/bfs"] = [169898, 204479, 173416, 208772, 171225, 228884, 176177, 168012, 171594, 172880]
cold_mem["py/bfs"] = [215632, 215564, 215568, 215700, 215820, 215828, 215628, 215828, 215824, 215940]
cold_lat["py/pr"] = [1961525, 1944363, 1998156, 1952014, 1967672, 2009118, 2072567, 1974747, 2054409, 1964040]
cold_mem["py/pr"] = [422524, 421140, 396084, 414484, 417128, 417060, 453444, 417280, 420656, 418156]
cold_lat["py/dna"] = [1187563, 1094948, 1090521, 1172336, 1254321, 1227648, 1104313, 1092235, 1287324, 1108494]
cold_mem["py/dna"] = [383764, 373668, 374016, 368824, 368084, 376180, 373608, 377068, 373760, 377244]
cold_lat["py/html"] = [1296368, 1742160, 1497556, 1292556, 1308773, 1305192, 1315933, 1981852, 1297316, 1308452]
cold_mem["py/html"] = [415324, 414544, 417060, 415012, 415372, 413488, 415364, 415804, 415332, 415460]
cold_lat["py/compress"] = [1397654, 1275623, 1260981, 1433489, 1552292, 1269223, 1393821, 1257196, 1258242, 1254371]
cold_mem["py/compress"] = [418468, 396900, 396892, 418552, 396228, 399240, 396424, 396992, 396956, 396972]
cold_lat["py/thumbnail"] = [929953, 932094, 933243, 936269, 954653, 948202, 942847, 943999, 935713, 935729]
cold_mem["py/thumbnail"] = [359928, 360132, 361108, 359988, 359256, 360080, 359856, 360000, 359972, 359276]
cold_lat["py/upload"] = [1201756, 1196617, 1193320, 1199357, 1168223, 1177484, 1191926, 1190121, 1198555, 1225245]
cold_mem["py/upload"] = [386444, 386396, 386572, 386316, 386396, 386440, 386392, 386464, 386460, 386384]
cold_lat["js/hw"] = [12551, 12277, 12204, 13054, 13373, 14738, 13132, 10614, 11866, 14320]
cold_mem["js/hw"] = [68716, 68720, 68652, 68308, 68652, 68716, 68720, 68720, 68720, 68308]
cold_lat["js/html"] = [42835, 32791, 34311, 34636, 36566, 30295, 28654, 32710, 28520, 32315, 33444, 28859, 33374, 35067, 28579, 31638, 30115, 35640, 34439, 28210]
cold_mem["js/html"] = [15840, 101516, 85864, 101520, 15840, 93784, 96420, 15840, 94444, 39860, 15840, 71264, 39860, 15840, 15840, 101452, 24888, 91700, 101520, 55060]
cold_lat["js/upload"] = [18572, 22977, 17056, 17122, 17887, 16976, 19777, 15720, 17119, 21102]
cold_mem["js/upload"] = [80548, 80544, 80476, 80544, 80484, 80480, 80480, 80548, 80544, 80544]

snap_lat = {}
warm_lat = {}
snap_mem = {}
snap_lat["py/hw"] = [10633, 11493, 10758, 10927, 12258, 10910, 9928, 12775, 11417, 11371]
warm_lat["py/hw"] = [9055, 9165, 9101, 9134, 9204, 9153, 9246, 9106, 9129, 8990]
snap_mem["py/hw"] = [51120, 51124, 51124, 51060, 51124, 51124, 50996, 51124, 51060, 51060]
snap_lat["py/mst"] = [12790, 13557, 13556, 14081, 14312, 14817, 15490, 12173, 12449, 14839]
warm_lat["py/mst"] = [9332, 11697, 9456, 11630, 9559, 9571, 9514, 11495, 9434, 11567]
snap_mem["py/mst"] = [68592, 68656, 68656, 68656, 68676, 68720, 68720, 68784, 68720, 68720]
snap_lat["py/bfs"] = [13036, 13907, 11592, 11521, 13845, 11429, 14960, 15379, 14144, 13018]
warm_lat["py/bfs"] = [9154, 9270, 9246, 9154, 9220, 9191, 9053, 9085, 9075, 9136]
snap_mem["py/bfs"] = [64612, 64548, 64676, 64548, 64484, 64612, 64612, 64612, 64612, 64612]
snap_lat["py/pr"] = [49989, 59088, 64340, 42455, 47920, 47544, 47264, 44047, 49385, 47590]
warm_lat["py/pr"] = [31216, 54359, 30706, 33844, 27376, 26254, 42833, 34258, 39353, 39366]
snap_mem["py/pr"] = [164500, 165656, 161884, 165792, 165440, 167684, 165480, 164616, 165704, 165836]
snap_lat["py/dna"] = [15094, 16296, 16240, 16632, 16062, 18103, 16824, 18360, 16168, 17002]
warm_lat["py/dna"] = [14732, 10526, 10383, 9953, 10618, 10762, 10746, 10713, 12513, 11047]
snap_mem["py/dna"] = [80880, 81004, 80812, 80992, 81004, 80940, 80884, 80992, 80872, 81168]
snap_lat["py/html"] = [92228, 79528, 81553, 78362, 78028, 72069, 491213, 66493, 64850, 82603]
warm_lat["py/html"] = [27171, 31351, 33089, 40575, 33037, 24437, 22189, 31490, 29434, 36104]
snap_mem["py/html"] = [195700, 195656, 196576, 197720, 192168, 196908, 339968, 195072, 195556, 196108]
snap_lat["py/compress"] = [195657, 407161, 460510, 207961, 388005, 549520, 259448, 397570, 401901, 389392]
warm_lat["py/compress"] = [112123, 113909, 106744, 143714, 116020, 113223, 145621, 107285, 106831, 106831]
snap_mem["py/compress"] = [299296, 360052, 357472, 301308, 358552, 361012, 300664, 357532, 358516, 358596]
snap_lat["py/thumbnail"] = [142245, 140769, 141141, 149198, 130288, 105764, 105982, 142967, 106728, 133258]
warm_lat["py/thumbnail"] = [77386, 110862, 114411, 92797, 104849, 101961, 104111, 102260, 102804, 100579]
snap_mem["py/thumbnail"] = [200400, 200800, 200276, 200056, 200412, 199640, 200404, 200220, 200060, 199824]
snap_lat["py/upload"] = [88440, 74596, 91331, 111984, 74578, 89857, 90763, 82705, 72100, 91771]
warm_lat["py/upload"] = [36296, 33607, 38323, 39353, 35176, 38271, 39631, 33053, 40137, 36431]
snap_mem["py/upload"] = [200904, 200960, 200932, 201540, 201172, 201052, 201924, 201108, 201652, 201100]
snap_lat["js/hw"] = [11243, 8871, 8941, 10611, 8931, 12180, 10044, 9803, 9133, 8710]
warm_lat["js/hw"] = [9028, 9077, 9175, 9133, 9068, 11140, 9057, 9020, 9259, 8994]
snap_mem["js/hw"] = [38708, 38772, 38772, 38772, 38772, 38772, 38708, 38708, 38772, 38768]
snap_lat["js/html"] = [11444, 11636, 11639, 13238, 11399, 9903, 11882, 11694, 12872, 11350, 10175, 11254, 11465, 11255, 10476, 11081, 12348, 12238, 12466, 12427]
warm_lat["js/html"] = [10171, 9784, 10116, 12023, 9881, 9676, 13400, 11930, 11670, 12137, 9906, 10026, 12184, 10291, 9897, 10257, 11721, 10188, 10250, 10031]
snap_mem["js/html"] = [56160, 56160, 56160, 56100, 56160, 56160, 56160, 56160, 56160, 56096, 56096, 56096, 56096, 56100, 56160, 56160, 56168, 56160, 56160, 56160]
snap_lat["js/upload"] = [11763, 13092, 12380, 16453, 12316, 14798, 12028, 11972, 12053, 11884]
warm_lat["js/upload"] = [10200, 10239, 10659, 9508, 11090, 10127, 10205, 10565, 10378, 11131]
snap_mem["js/upload"] = [57024, 57024, 57024, 57024, 57020, 57024, 57024, 57024, 57024, 56960]


cold_total = []
cold_total_std = []
cold_memory = []
cold_memory_std = []
for bench in benchmark_labels:
    cold_total.append(np.mean(cold_lat[bench]))
    cold_total_std.append(np.std(cold_lat[bench]))
    cold_memory.append(np.mean(cold_mem[bench]))
    cold_memory_std.append(np.std(cold_mem[bench]))
# Converting KBs to MBs.
cold_memory = [float(x) / 1024.0 for x in cold_memory]

snap_total = []
snap_total_std = []
snap_memory = []
snap_memory_std = []
for bench in benchmark_labels:
    snap_total.append(np.mean(snap_lat[bench]))
    snap_total_std.append(np.std(snap_lat[bench]))
    snap_memory.append(np.mean(snap_mem[bench]))
    snap_memory_std.append(np.std(snap_mem[bench]))
# Converting KBs to MBs.
snap_memory = [float(x) / 1024.0 for x in snap_memory]

warm_total = []
warm_total_std = []
warm_memory = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
warm_memory_std = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
for bench in benchmark_labels:
    warm_total.append(np.mean(warm_lat[bench]))
    warm_total_std.append(np.std(warm_lat[bench]))

# print(cold_total)
# print(snap_total)
# Normalized entrypoint.
li = [x / y for x, y in zip(cold_total, snap_total)]
mi = [x / y for x, y in zip(cold_memory, snap_memory)]
print("Normalized latency improvement:")
print(li)
print("Normalized memory improvement:")
print(mi)
print("Average latency improvement:" + str(sum(li) / len(li)) )
print("Average memry improvement:" + str(sum(mi) / len(mi)) )
print(max(cold_memory))


x = np.arange(len(benchmark_labels))
plt.rcParams.update({'font.size': 10})
fig, axs = plt.subplots(2)
width = 0.3

axs[0].bar(x + -0.5*width, cold_total,  width=width, hatch='...', label='Cold',  alpha=0.75)
axs[0].bar(x + 0.5*width, snap_total,     width=width, hatch='|||', label='Snap',  alpha=0.75)
axs[0].bar(x + 1.5*width, warm_total,     width=width, hatch='ooo', label='Warm',  alpha=0.75)

axs[1].bar(x + -0.5*width, cold_memory,    width=width, hatch='...', label='Cold',  alpha=0.75)
axs[1].bar(x + 0.5*width, snap_memory,  width=width, hatch='|||', label='Snap',  alpha=0.75)
axs[1].bar(x + 1.5*width, warm_memory,  width=width, hatch='ooo', label='Warm',  alpha=0.75)
axs[0].set_xticks([])
axs[1].set_xticks(x, benchmark_labels)
axs[1].legend(ncol=1, loc='upper left')
# axs[1].set_ylim(ymax=100000000)

plt.xticks(rotation = 45)
axs[0].grid(axis = 'y', linestyle = '--', linewidth = 0.25)
axs[1].grid(axis = 'y', linestyle = '--', linewidth = 0.25)
axs[0].set_ylabel('Latency (us)')
axs[1].set_ylabel('Memory (MBs)')
axs[0].set_yscale('log')
axs[1].set_yscale('log')
fig.set_figwidth(7)
fig.set_figheight(3)

plt.savefig("sandboxes-snapshot.pdf", bbox_inches='tight')
plt.savefig("sandboxes-snapshot.png", bbox_inches='tight')
