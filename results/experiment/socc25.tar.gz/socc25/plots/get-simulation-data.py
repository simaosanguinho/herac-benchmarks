#!/usr/bin/python

declarations = __import__("sandboxes-declarations")
import os
import numpy as np


experiment = declarations.experiment
benchmark_labels = declarations.benchmark_labels
isolate_benchmark_path = declarations.isolate_benchmark_path
process_benchmark_path = declarations.process_benchmark_path
openwhisk_benchmark_path = declarations.openwhisk_benchmark_path
nitf_benchmark_path = declarations.nitf_benchmark_path
knative_benchmark_path = declarations.knative_benchmark_path

lang_map = {
    "js": "javascript",
    "py": "python",
    "jv": "java"
}


def get_lang(line):
    if "/gv-" in line:
        gv_lang = line.split("/gv-")[1].split("-")[0]
        return lang_map[gv_lang]
    else:
        return line.split("../")[1].split("/")[0]

def get_runtime(line):
    return line.split("/")[2].split("-")[0]

def get_bench(line):
    if "/gv-" in line:
        return line.split("-", 1)[1].split("-", 1)[1].split("-container")[0].replace("-", "")
    else:
        return line.split("-", 1)[1].split("-container")[0].replace("-", "")

def get_sandbox(line):
    return line.split("-cold-")[1].split("-benchmark-")[0]


def read_benchmark_throughput(path):
    tput = []
    try:
        with open(path + '/ab.log') as file:
            for line in file:
                if 'Requests per second:' in line:
                    tput.append(float(line.split()[3]))
    except Exception as e:
        print("Error processing " + path + ":")
        raise e
    return tput

def read_benchmark_mean_latency(path):
    mean_lat = []
    try:
        with open(path + '/ab.log') as file:
            for line in file:
                if 'Time per request:' in line and '(mean)' in line:
                    if '[ms]' in line:
                        mean_lat.append(float(line.split()[3]))
                    else:
                        print("Warning, non-ms latency record: {ab_line}".format(ab_line=line))
    except Exception as e:
        print("Error processing " + path + ":")
        raise e
    return mean_lat

def read_benchmark_memory(path):
    mem = []
    try:
        mem = []
        with open(path + '/lambda.rss') as file:
            for line in file:
                mem.append(int(line))
        if len(mem) < 7:
            pass
            # print("Warning, not enough memory data points from {path}".format(path=path))
        # Use the last 5 samples before the last one.
        mem = mem[-6:-1]
    except Exception as e:
        print("Error processing " + path + ":")
        raise e
    return mem

def process_result(path):
    try:
        return process_result_internal(path)
    except FileNotFoundError:
        print("Warning, {path} not found".format(path=path))


def process_result_internal(path):
    # Mean latency of each iteration.
    mean_lat = []
    # Memory samples (rss in kbs) of each iteration.
    mem = []
    tput = []

    for file in os.scandir(path):
        if file.is_dir():
            mem.extend(read_benchmark_memory(file.path))
            mean_lat.extend(read_benchmark_mean_latency(file.path))
            tput.extend(read_benchmark_throughput(file.path))

    # Convert to numpy arrays (help with mean and std).
    mean_lat = np.array(mean_lat)
    mem = np.array(mem)
    tput = np.array(tput)

    # Convertion from kbs to mbs
    mem = mem / 1024

    mean_lat_avg = round(mean_lat.mean(), 3)
    mean_lat_std = round(mean_lat.std(), 3)
    mem_avg = round(mem.mean(), 3)
    mem_std = round(mem.std(), 3)
    tput_avg = round(tput.mean(), 3)
    tput_std = round(tput.std(), 3)

    runtime = get_runtime(path)
    sandbox = get_sandbox(path)
    lang = get_lang(path)
    bench = get_bench(path)

    eff_avg = tput_avg / (mem_avg / 1024)

    # Print everything with sandbox
    print("{runtime}_{lang}_{bench},{mem_avg},{mean_lat_avg},{tput_avg},{eff_avg}".format(runtime=runtime, lang=lang, bench=bench, mem_avg=mem_avg, mean_lat_avg=mean_lat_avg, tput_avg=tput_avg, eff_avg=eff_avg))



def run():
    print("benchmark,sandbox,mem_avg_mb,mean_lat_avg_ms,tput_avg,eff_avg")

    # Processing results.
    for idx, path in enumerate(isolate_benchmark_path):
        process_result(experiment + path)
        # process_result(experiment + path)["eff_std"]
    for idx, path in enumerate(process_benchmark_path):
        pass
        # process_result(experiment + path)
        # process_result(experiment + path)["eff_std"]
    for idx, path in enumerate(openwhisk_benchmark_path):
        process_result(experiment + path)
        # process_result(experiment + path)["eff_std"]
    for idx, path in enumerate(nitf_benchmark_path):
        pass
        # process_result(experiment + path)
        # process_result(experiment + path)["eff_std"]
    for idx, path in enumerate(knative_benchmark_path):
        process_result(experiment + path)
        # process_result(experiment + path)["eff_std"]


run()
