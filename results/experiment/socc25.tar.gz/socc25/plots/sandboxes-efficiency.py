#!/usr/bin/env python

declarations = __import__("sandboxes-declarations")
import results
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import statistics

experiment = declarations.experiment
benchmark_labels = declarations.benchmark_labels
isolate_benchmark_path = declarations.isolate_benchmark_path
process_benchmark_path = declarations.process_benchmark_path
openwhisk_benchmark_path = declarations.openwhisk_benchmark_path
nitf_benchmark_path = declarations.nitf_benchmark_path
knative_benchmark_path = declarations.knative_benchmark_path

# Efficiency in ops/s/gb.
isolate_eff_avg = {}
isolate_eff_std = {}
process_eff_avg = {}
process_eff_std = {}
openwhisk_eff_avg = {}
openwhisk_eff_std = {}
nitf_eff_avg = {}
nitf_eff_std = {}
knative_eff_avg = {}
knative_eff_std = {}

# Processing results.
for idx, path in enumerate(isolate_benchmark_path):
    isolate_eff_avg[idx] = results.process_result(experiment + path)["eff_avg"]
    isolate_eff_std[idx] = results.process_result(experiment + path)["eff_std"]
for idx, path in enumerate(process_benchmark_path):
    process_eff_avg[idx] = results.process_result(experiment + path)["eff_avg"]
    process_eff_std[idx] = results.process_result(experiment + path)["eff_std"]
for idx, path in enumerate(openwhisk_benchmark_path):
    openwhisk_eff_avg[idx] = results.process_result(experiment + path)["eff_avg"]
    openwhisk_eff_std[idx] = results.process_result(experiment + path)["eff_std"]
for idx, path in enumerate(nitf_benchmark_path):
    nitf_eff_avg[idx] = results.process_result(experiment + path)["eff_avg"]
    nitf_eff_std[idx] = results.process_result(experiment + path)["eff_std"]
for idx, path in enumerate(knative_benchmark_path):
    knative_eff_avg[idx] = results.process_result(experiment + path)["eff_avg"]
    knative_eff_std[idx] = results.process_result(experiment + path)["eff_std"]

# Printing some normalized results.
normalized = []
for idx, path in enumerate(isolate_benchmark_path):
    normalized.append(isolate_eff_avg[idx]/openwhisk_eff_avg[idx])
print("Avg. efficiency normalized to OpenWhisk: " + str(statistics.median(normalized)))


x = np.arange(len(benchmark_labels))
width = 0.15

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
plt.rcParams.update({'font.size': 12})
fig, ax = plt.subplots()
ax.bar(x + -2*width, isolate_eff_avg.values(),   yerr=isolate_eff_std.values(),   width=width, hatch='*', label='Hydra',  alpha=0.75)
ax.bar(x + -1*width, process_eff_avg.values(),   yerr=process_eff_std.values(),   width=width, hatch='.', label='Forking',     alpha=0.75)
ax.bar(x + 0*width, nitf_eff_avg.values(),      yerr=nitf_eff_std.values(),   width=width, hatch='O', label='NITF',     alpha=0.75)
ax.bar(x + 1*width, openwhisk_eff_avg.values(), yerr=openwhisk_eff_std.values(), width=width, hatch='-', label='OpenWhisk',   alpha=0.75)
ax.bar(x + 2*width, knative_eff_avg.values(),  yerr=knative_eff_std.values(),  width=width, hatch='/', label='Knative', alpha=0.75)

ax.set_ylabel('Density (ops/GB-sec)')
ax.set_xticks(x, benchmark_labels)
ax.set_axisbelow(True)
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.25)
plt.xticks(rotation = 35)
ax.set_yscale('log')
ax.set_ylim(ymax=50000000)
ax.set_xlim(x[0] - 5*width, x[-1] + 5*width)
#ax.set_xlim(xmin=-.25, xmax=14.7)
fig.set_figwidth(15)
fig.set_figheight(3)

ax.legend(ncol=5, loc='upper right')
plt.savefig("sandboxes-efficiency.pdf", bbox_inches='tight')
plt.savefig("sandboxes-efficiency.png", bbox_inches='tight')
plt.show()