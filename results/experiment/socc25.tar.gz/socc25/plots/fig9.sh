#!/bin/bash

# Execute next to the "benchmark-graalvisor.sh" script.
# Produces 

TEST_SET="gv_python_hw gv_python_mst gv_python_bfs gv_python_pagerank gv_python_dna gv_python_dynamichtml gv_python_compression gv_python_thumbnail gv_python_uploader gv_javascript_hw gv_javascript_dynamichtml gv_javascript_uploader"
TEST_SET="gv_javascript_dynamichtml"

ITER=20

function run_cold {

    for bench in $TEST_SET; do

        total_latency=0
        total_memory=0

        latency_arr=""
        memory_arr=""

        for iter in $(seq 1 $ITER); do
            latency=$(SANDBOX=context WORK_DIR=/tmp/exp bash benchmark-graalvisor.sh svm $bench test 1 | grep "Req latency" 2> /dev/null)
            latency=$(echo $latency | awk '{print $3}')
            memory=$(cat /tmp/exp/bench/lambda.rss | sort -r | head -n 1)

            total_latency=$((total_latency + latency))
            total_memory=$((total_memory + memory))

            latency_arr="$latency_arr, $latency"
            memory_arr="$memory_arr, $memory"
        done

        avg_latency=$((total_latency / ITER))
        avg_memory=$((total_memory / ITER))

        echo "*** Bench: $bench ***"
        echo "Avg latency: $avg_latency"
        echo "Avg memory: $avg_memory"

        echo "cold_lat[\"$bench\"] = [$latency_arr]"
        echo "cold_mem[\"$bench\"] = [$memory_arr]"
    done
}

function run_snap_warm {

    for bench in $TEST_SET; do

        checkpoint_total_latency=0

        snap_total_latency=0
        snap_total_memory=0
        snap_latency_arr=""
        snap_memory_arr=""

        warm_total_latency=0
        warm_latency_arr=""

        for iter in $(seq 1 $ITER); do
            checkpoint_latency=$(SANDBOX=snapshot-process WORK_DIR=/tmp/exp bash benchmark-graalvisor.sh svm $bench test 1 | grep "Req latency" 2> /dev/null)
            checkpoint_latency=$(echo $checkpoint_latency | awk '{print $3}')
            checkpoint_total_latency=$((checkpoint_total_latency + checkpoint_latency))

            latencies=$(KEEP_SNAPSHOTS=true SANDBOX=snapshot-process WORK_DIR=/tmp/exp bash benchmark-graalvisor.sh svm $bench test 10 | grep "Req latency" | awk '{print $3}' 2> /dev/null)
            restore_latency=$(echo $latencies | awk '{print $1}')
            warm_latency=$(echo $latencies | awk '{for(i=NF-4;i<=NF;i++) sum+=$i; print sum/5}')
            # To truncate decimal part.
            warm_latency=${warm_latency%.*}
            
            snap_total_latency=$((snap_total_latency + restore_latency))
            warm_total_latency=$((warm_total_latency + warm_latency))

            snap_latency_arr="$snap_latency_arr, $restore_latency"
            warm_latency_arr="$warm_latency_arr, $warm_latency"

            latencies=$(KEEP_SNAPSHOTS=true SANDBOX=snapshot-process WORK_DIR=/tmp/exp bash benchmark-graalvisor.sh svm $bench test 1 &> /dev/null)
            memory=$(cat /tmp/exp/bench/lambda.rss | sort -r | head -n 1)

            snap_total_memory=$((snap_total_memory + memory))
            snap_memory_arr="$snap_memory_arr, $memory"
        done

        avg_checkpoint_latency=$((checkpoint_total_latency / ITER))

        avg_snap_latency=$((snap_total_latency / ITER))
        avg_warm_latency=$((warm_total_latency / ITER))
        avg_snap_memory=$((snap_total_memory / ITER))

        echo "*** Bench: $bench ***"
        echo "Avg checkpoint latency: $avg_checkpoint_latency"
        echo "Avg restore latency: $avg_snap_latency"
        echo "Avg warm latency: $avg_warm_latency"
        echo "Avg restore memory: $avg_snap_memory"

        echo "snap_lat[\"$bench\"] = [$snap_latency_arr]"
        echo "warm_lat[\"$bench\"] = [$warm_latency_arr]"
        echo "snap_mem[\"$bench\"] = [$snap_memory_arr]"
    done
}

run_cold > cold.log
run_snap_warm > snap_warm.log
